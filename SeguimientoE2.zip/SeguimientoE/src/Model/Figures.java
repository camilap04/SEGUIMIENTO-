package Model;

public class Figures {
	int posX;
	int posY;
	protected int width;
	protected int heigh;
	Color color;
	

	public Figures(int _posX, int _posY, int _width, int _heigh) {
		this.posX = _posX;
		this.posY = _posY;
		this.width = _width;
		this.heigh = _heigh;
		this.color = new Color(250, 250, 250);
	}

	public Color SetColor(int R, int G, int B) {
		this.color.setColor(R, G, B);
		
		return this.color;
	}

	public boolean hasBeenClick(int _posX, int _posY) {
		boolean isInXrange = _posX > (posX - width / 2) && _posX < (posX + width / 2);
		boolean isInYrange = _posY > (posY - heigh / 2) && _posY < (posY + heigh / 2);
		return isInXrange && isInYrange;
	}
	
	
	
	


}

package Model;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Bar implements Drawvable {
	ArrayList<ColorSelector> data;
	int posX;
	int posY;
	PApplet app; 
	PImage img; 

	public Bar(int _posY, PApplet _app) {
		ColorSelector color1 = new ColorSelector(200, 220, new Color(226, 77, 19));
		ColorSelector color2 = new ColorSelector(220, 240, new Color(226, 212, 30));
		ColorSelector color3 = new ColorSelector(240, 260, new Color(111, 226, 36));
		ColorSelector color4 = new ColorSelector(260, 280, new Color(48, 209, 113));
		ColorSelector color5 = new ColorSelector(280, 300, new Color(31, 220, 229));
		ColorSelector color6 = new ColorSelector(300, 320, new Color(51, 113, 226));
		ColorSelector color7 = new ColorSelector(320, 340, new Color(164, 42, 216));
		ColorSelector color8 = new ColorSelector(340, 360, new Color(211, 47, 152));
		ColorSelector color9 = new ColorSelector(360, 380, new Color(242, 3, 101));
		ColorSelector color10 = new ColorSelector(380, 400, new Color(249, 6, 6));
		this.data = new ArrayList<ColorSelector>();
		this.data.add(color1);
		this.data.add(color2);
		this.data.add(color3);
		this.data.add(color4);
		this.data.add(color5);
		this.data.add(color6);
		this.data.add(color7);
		this.data.add(color8);
		this.data.add(color9);
		this.data.add(color10);
		this.posY = _posY;
		this.posX = 200;
		this.app = _app; 
		this.img = app.loadImage("Bar.jpg");
	}

	@Override
	public void draw() {
		
		app.image(img, posX, posY);
		

	}

}

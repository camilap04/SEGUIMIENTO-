package Model;

public class NoColorException extends Exception{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoColorException() {
		super ("Error, no se ha seleccionado ningun color para la figura");
	}

}

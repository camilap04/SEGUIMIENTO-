package Model;

import processing.core.PApplet;

public class Pointer extends Figures implements Drawvable {
	PApplet app;

	public Pointer(int _posX, int _posY, int _width, int _heigh, PApplet _app) {
		super(_posX, _posY, _width, _heigh);
		this.app = _app;
	}

	@Override
	public void draw() {
		
		app.fill(242, 187, 170);
		app.ellipse(posX, posY, heigh, width);
	}

	public void move(int _posX) {
		if (isposXinRange(_posX))
		this.posX = _posX;
		

	}
	
	

	private boolean isposXinRange(int _posX) {
		if (_posX > 200 && _posX < 400) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	
}

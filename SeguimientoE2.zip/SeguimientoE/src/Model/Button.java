package Model;

public class Button {

}

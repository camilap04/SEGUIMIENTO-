package Model;

public class Color {
	int R;
	int G;
	int B;

	public Color(int _R, int _G, int _B) {
		this.R = _R;
		this.G = _G;
		this.B = _B;
	}
	public void setColor(int _R, int _G, int _B) {
		this.R = _R;
		this.G = _G;
		this.B = _B;
		
		
	
	}
	
public int getB() {
	return B;
}

public int getG() {
	return G;
}
public int getR() {
	return R;
}

	

}

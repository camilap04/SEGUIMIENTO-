package Model;

public class NotMatchException extends Exception{
	
	public NotMatchException() {
		super ("Error, los colore de las figuras no coinciden ");
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}

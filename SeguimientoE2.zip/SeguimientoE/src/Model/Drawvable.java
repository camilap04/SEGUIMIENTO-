package Model;

public interface Drawvable {
	public void draw();

}

package Model;

import processing.core.PApplet;

public class Circle extends Figures implements Drawvable {
	PApplet app;
	boolean isSelected;
	
	int R,G,B;

	public Circle(int _posX, int _posY, int _width, int _heigh, PApplet _app) {
		super(_posX, _posY, _width, _heigh);
		this.app = _app;
		this.isSelected = false;
		
	}

	@Override
	public void draw() {
		app.fill(color.R, color.G, color.B);
		app.ellipse(posX, posY, heigh, width);
		
	}
	
	public void mouseClick() {
		selectColor(color.R, color.G, color.B);
		R= color.R;
		G= color.G;
		B= color.B;
	}
	
	public void clearCircle() {
		color.setColor(250,250,250);
	}
	

	public void select(int _posX, int _posY, Square square) {
		if (hasBeenClick(_posX, _posY)) {
			isSelected = true;
			square.isSelected = false; 
		}
	}
	
	public void selectColor(int R, int G, int B) {
		
		
		
		if (app.mouseX > 113 && app.mouseX < 218 && isSelected && app.mouseY < 324 && app.mouseY > 300) {
			color.setColor(226, 77, 19);
			
		}
		
		if (app.mouseX > 219 && app.mouseX < 235 && isSelected && app.mouseY < 324 && app.mouseY > 300) {
			
			color.setColor(226, 211, 30);
		}
		
		if (app.mouseX > 236 && app.mouseX < 258 && isSelected && app.mouseY < 324 && app.mouseY > 300) {
			color.setColor(111, 226, 35);

		}
		
		if (app.mouseX > 259 && app.mouseX < 279 && isSelected && app.mouseY < 324 && app.mouseY > 300) {
			
			color.setColor(48, 209, 113);
		}
		
		if (app.mouseX > 280 && app.mouseX < 297 && isSelected && app.mouseY < 324 && app.mouseY > 300) {

			color.setColor(32, 220, 229);
		}
		
		if (app.mouseX > 298 && app.mouseX < 316 && isSelected && app.mouseY < 324 && app.mouseY > 300) {

			color.setColor(51, 113, 226);
		}
		
		if (app.mouseX > 317 && app.mouseX < 338 && isSelected && app.mouseY < 324 && app.mouseY > 300) {

			color.setColor(317, 42, 215);
		}
		
		if (app.mouseX > 339 && app.mouseX < 353 && isSelected && app.mouseY < 324 && app.mouseY > 300) {

			color.setColor(210, 47, 152);
		}
		
		if (app.mouseX > 354 && app.mouseX < 378 && isSelected && app.mouseY < 324 && app.mouseY > 300) {
			color.setColor(243, 3, 102);
		}
		
		if (app.mouseX > 379 && app.mouseX < 407 && isSelected && app.mouseY < 324 && app.mouseY > 300) {

			color.setColor(250, 6, 6);
		}
	}
	public int getB() {
		return B;
	}
	public int getG() {
		return G;
	}
	public int getR() {
		return R;
	}
	
}


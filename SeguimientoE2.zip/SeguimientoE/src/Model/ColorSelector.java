package Model;

public class ColorSelector {
	int posxI; 
	int posxF;
	Color color; 
	
	public ColorSelector(int _posxI, int _posxF, Color _color) {
		this.posxI = _posxI; 
		this.posxF = _posxF;
		this.color = _color; 
		System.out.println(posxI);

	}

}

package controller;

import java.util.ArrayList;

import Model.Bar;
import Model.Circle;
import Model.Drawvable;
import Model.Pointer;
import Model.Square;
import processing.core.PApplet;

public class AppController {
	PApplet app;
	ArrayList<Drawvable> elements;

	public AppController(PApplet _app) {
		this.app = _app;
	}

	public void initialize() {
		this.elements = new ArrayList<Drawvable>();
		Circle circle = new Circle(380, 200, 90, 90, app);
		Square square = new Square(220, 200, 90, 90, app);
		Bar bar = new Bar(300, app);
		Pointer pointer = new Pointer (210,325,16,16,app);
		elements.add(circle);
		elements.add(square);
		elements.add(bar);
		

	}

	public void drawElements() {
		elements.forEach(element -> element.draw());
	}
	
	public Pointer getPointer() {
		return(Pointer)this.elements.get(3);
	}
	
	public Circle getCircle() {
		return(Circle)this.elements.get(0);
	}
	
	public Square getSquare() {
		return(Square)this.elements.get(1);
	}
	public Bar getbar() {
		return(Bar)this.elements.get(2);
	}
}

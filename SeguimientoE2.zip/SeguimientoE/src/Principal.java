import Model.Bar;

import Model.Circle;
import Model.Pointer;
import Model.Square;
import controlP5.ControlP5;
import controller.AppController;
import processing.core.PApplet;
;

public class Principal extends PApplet {

	AppController controller;
	Pointer pointer; 
	Circle circle; 
	Square square; 
	Bar bar;
	
	boolean R,G,B;
	private ControlP5 cp5;

	public static void main(String[] args) {
		PApplet.main(Principal.class.getName());
	}

	@Override
	public void settings() {
		size(600, 500);
		R=false;
		G=false;
		B=false;
	}

	@Override
	public void setup() {
		controller = new AppController(this);
		controller.initialize();
		//this.pointer = controller.getPointer();
		this.circle = controller.getCircle();
		this.square = controller.getSquare();
		this.bar = controller.getbar();
		cp5 = new ControlP5(this);
		
		cp5.addBang("compare").setPosition(180, 400).setSize(110, 40).setLabel("Comparar").getCaptionLabel()
		.align(ControlP5.CENTER, ControlP5.CENTER);

		cp5.addBang("clear").setPosition(305, 400).setSize(110, 40).setLabel("Limpiar").getCaptionLabel()
		.align(ControlP5.CENTER, ControlP5.CENTER);
	}

	@Override
	public void draw() {
		rectMode(CENTER);
		background (250);
		controller.drawElements();

	}

	public void mouseDragged() {
       //this.pointer.move(mouseX);
	}
	
	public void mousePressed() {
	   this.circle.select(mouseX, mouseY, this.square);  
	   this.square.select(mouseX, mouseY, this.circle);
	   this.circle.mouseClick();
	   this.square.mouseClick();
	}
	
	public void compare() {
		
		
		if(circle.getR()== square.getR()){
			R=true;
		}else {
			R=false;
		}
		if(circle.getG()== square.getG()){
			G=true;
		}else {
			G=false;
		}
		
		if(circle.getB()== square.getB()){
			B=true;
		}else {
			B=false;
		}
		
		if(R==true&&G==true&&B==true){
			
			System.out.println("Los colores coinciden");
		}else {
			System.out.println("Error, los colores de las figuras no coinciden ");;
		}
		
	}
	
	public void clear() {
		
		this.circle.clearCircle();
		this.square.clearSquare();
	}
}